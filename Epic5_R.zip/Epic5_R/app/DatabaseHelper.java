import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "VehiculoData.db";
    private static final int DATABASE_VERSION = 1;

    public static final String TABLE_VEHICULO = "vehiculo";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_CAPACIDAD_PERSONAS = "capacidad_personas";
    public static final String COLUMN_PLACA = "placa";
    public static final String COLUMN_TARJETA_CIRCULACION_SOAT = "tarjeta_circulacion_soat";

    private static final String DATABASE_CREATE =
            "create table " + TABLE_VEHICULO + " (" +
                    COLUMN_ID + " integer primary key autoincrement, " +
                    COLUMN_CAPACIDAD_PERSONAS + " text not null, " +
                    COLUMN_PLACA + " text not null, " +
                    COLUMN_TARJETA_CIRCULACION_SOAT + " text not null);";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase database) {
        database.execSQL(DATABASE_CREATE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_VEHICULO);
        onCreate(db);
    }
}
