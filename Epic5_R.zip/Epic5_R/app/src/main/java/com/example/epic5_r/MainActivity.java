package com.example.epic5_r;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText capacidadPersonasEditText, placaEditText, tarjetaCirculacionSOATEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        capacidadPersonasEditText = findViewById(R.id.capacidadPersonas);
        placaEditText = findViewById(R.id.placa);
        tarjetaCirculacionSOATEditText = findViewById(R.id.tarjetaCirculacionSOAT);

        Button botonGuardar = findViewById(R.id.botonGuardar);
        botonGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                guardarDatos();
            }
        });
}

    private void guardarDatos() {
        String capacidadPersonas = capacidadPersonasEditText.getText().toString();
        String placa = placaEditText.getText().toString();
        String tarjetaCirculacionSOAT = tarjetaCirculacionSOATEditText.getText().toString();

        // Aquí puedes agregar la lógica para guardar los datos en una base de datos o donde sea necesario.
        // Por ahora, solo mostraremos un mensaje de confirmación.

        String mensaje = "Datos guardados:\nCapacidad: " + capacidadPersonas +
                "\nPlaca: " + placa +
                "\nTarjeta de Circulación y SOAT: " + tarjetaCirculacionSOAT;

        Toast.makeText(this, mensaje, Toast.LENGTH_LONG).show();
    }

}





